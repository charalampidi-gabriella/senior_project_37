^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur
^^^^^^^^^^^^^^^^^^^^^^^^

2.4.1 (2023-09-21)
------------------

2.4.0 (2023-08-28)
------------------

2.3.2 (2023-06-02)
------------------

2.3.1 (2023-03-16)
------------------

2.3.0 (2023-03-02)
------------------

2.2.4 (2022-10-07)
------------------

2.2.3 (2022-07-27)
------------------

2.2.2 (2022-07-19)
------------------

2.2.1 (2022-06-27)
------------------

2.2.0 (2022-06-20)
------------------
* wip
* Rework bringup (`#403 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/403>`_)
  * Copy all bringup files to ur_robot_driver
  * Update documentation to use launchfiles from ur_robot_driver
  * Add deprecation warnings for ur_bringup
  * Add ``ur`` metapackage
  * Added deprecation warning to toplevel README
  * Added meta package to CI checks
* Contributors: Felix Exner

* Rework bringup (`#403 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/403>`_)
* Contributors: Felix Exner

0.0.3 (2020-10-29)
------------------
