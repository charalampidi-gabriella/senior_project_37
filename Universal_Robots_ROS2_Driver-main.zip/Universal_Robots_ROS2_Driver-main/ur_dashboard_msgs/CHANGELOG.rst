^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur_dashboard_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.4.1 (2023-09-21)
------------------

2.4.0 (2023-08-28)
------------------

2.3.2 (2023-06-02)
------------------

2.3.1 (2023-03-16)
------------------

2.3.0 (2023-03-02)
------------------

2.2.4 (2022-10-07)
------------------

2.2.3 (2022-07-27)
------------------

2.2.2 (2022-07-19)
------------------
* Made sure all past maintainers are listed as authors (`#429 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/429>`_)
* Contributors: Felix Exner

2.2.1 (2022-06-27)
------------------

2.2.0 (2022-06-20)
------------------
* Updated package maintainers
* Update license to BSD-3-Clause (`#277 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/277>`_)
* Review CI by correcting the configurations (`#71 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/71>`_)
* Use GitHub Actions, use pre-commit formatting (`#56 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/56>`_)
* Add XML schema to all ``package.xml`` files
* Compile ur_dashboard_msgs for ROS2
* Contributors: AndyZe, Denis Štogl, Felix Exner, John Morris, livanov93
